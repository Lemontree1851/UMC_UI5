sap.ui.define([
	"sd/salesdocumentreport/test/unit/controller/salesdocumentreport.controller"
], function () {
	"use strict";
});
